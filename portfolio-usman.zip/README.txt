HOW TO RUN THIS PORTFOLIO
==========================

1. Unzip this folder anywhere on your computer (e.g. Desktop/my-portfolio).
2. Keep index.html, style.css, and script.js in the SAME folder.
3. Add your own files into this same folder:
   - "my pic.jpeg"      -> your profile photo
   - "My Resume..pdf"   -> your resume PDF
   (or edit index.html and change these two filenames to match your files)
4. Open index.html by double-clicking it, OR in VS Code:
   - Open the folder in VS Code (File > Open Folder)
   - Install the "Live Server" extension if you don't have it
   - Right-click index.html > "Open with Live Server"

IMPORTANT - IF YOU SEE NO ANIMATION:
=====================================
If animations don't seem to run, check your OS/browser's
"reduce motion" / "show animations" accessibility setting:
  - Windows: Settings > Accessibility > Visual effects > Animation effects
  - Edge/Chrome: usually inherits the Windows setting above
This build no longer respects that setting (animations are forced on),
so this shouldn't be the cause anymore - but if you still see a static
page, open DevTools (F12) > Console tab and check for red errors, and
make sure you have an internet connection (fonts/icons load from a CDN).

WHAT'S ANIMATED
================
- Small cyan dot next to your name pulses/glows continuously.
- Headline types itself out, pauses, deletes, and cycles through three
  roles on a loop (edit the "phrases" array near the top of script.js).
- The 6 tech icon badges around your photo fade in/out on a staggered
  loop AND their border pulses with a glow, while gently floating.
- Your profile photo has a pulsing glowing border and floats up and down
  continuously.
- Every card (skills, services, projects, certs, testimonials, about)
  slides up individually and snaps into place with a bounce as YOU
  scroll past it - staggered, not all at once.
- Once a card has slid into place, it starts a slow continuous float
  (up/down bob), and each card has a soft glowing halo just outside its
  border that pulses on a loop.
- Hovering any card tilts it in 3D toward your cursor (the idle float
  pauses while you hover, then resumes when you move away).
- A network of moving particles drifts behind everything on the page.
- The nav pill highlights whichever section you've scrolled to.
